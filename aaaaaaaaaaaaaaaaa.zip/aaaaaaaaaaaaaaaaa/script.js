document.addEventListener('DOMContentLoaded', function () {
    const transactionForm = document.getElementById('transaction-form');
    const transactionList = document.getElementById('transaction-list');
    const pendingList = document.getElementById('pending-list');
    const balanceList = document.getElementById('balance-list');
    const fromAccountInput = document.getElementById('from-account');
    const toAccountInput = document.getElementById('to-account');
    const fromAccountDatalist = document.getElementById('from-account-options');
    const toAccountDatalist = document.getElementById('to-account-options');

    let transactions = [];
    let categories = new Set();
    let balanceMap = {};  // Track balance between accounts

    transactionForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const amountInput = document.getElementById('amount').value.trim();
        // Convert comma to dot for parsing
        const amount = parseFloat(amountInput.replace(',', '.'));

        const fromAccount = fromAccountInput.value.trim();
        const toAccount = toAccountInput.value.trim();
        const type = document.getElementById('type').value;
        const description = document.getElementById('description').value.trim();

        if (!fromAccount || !toAccount || isNaN(amount)) {
            alert("Entrambe le categorie devono essere specificate e l'importo deve essere valido.");
            return;
        }

        categories.add(fromAccount);
        categories.add(toAccount);
        updateCategoryOptions();

        const transaction = {
            amount,
            fromAccount,
            toAccount,
            type,
            description
        };

        transactions.push(transaction);
        addTransaction(transaction);
        updateBalanceMap(transaction);
        calculateBalances();
        transactionForm.reset();
    });

    function updateCategoryOptions() {
        fromAccountDatalist.innerHTML = '';
        toAccountDatalist.innerHTML = '';
        categories.forEach(category => {
            const optionFrom = document.createElement('option');
            optionFrom.value = category;
            fromAccountDatalist.appendChild(optionFrom);

            const optionTo = document.createElement('option');
            optionTo.value = category;
            toAccountDatalist.appendChild(optionTo);
        });
    }

    function addTransaction(transaction) {
        const li = document.createElement('li');
        li.innerHTML = `
            ${transaction.amount.toFixed(2).replace('.', ',')} CHF da ${transaction.fromAccount} a ${transaction.toAccount} (${transaction.type})
            <br>
            <strong>Descrizione:</strong> ${transaction.description || 'Nessuna'}
        `;

        // Create and add edit and delete buttons
        const editButton = document.createElement('button');
        editButton.textContent = 'Modifica';
        editButton.className = 'edit-button';
        editButton.addEventListener('click', function () {
            editTransaction(transaction, li);
        });

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Elimina';
        deleteButton.className = 'delete-button';
        deleteButton.addEventListener('click', function () {
            removeTransaction(transaction, li);
        });

        li.appendChild(editButton);
        li.appendChild(deleteButton);

        if (transaction.type === 'completato') {
            transactionList.appendChild(li);
        } else {
            pendingList.appendChild(li);
        }
    }

    function editTransaction(transaction, listItem) {
        document.getElementById('amount').value = transaction.amount.toFixed(2).replace('.', ',');
        fromAccountInput.value = transaction.fromAccount;
        toAccountInput.value = transaction.toAccount;
        document.getElementById('type').value = transaction.type;
        document.getElementById('description').value = transaction.description;

        // Remove the transaction from the list
        listItem.remove();
        transactions = transactions.filter(t => t !== transaction);
        updateBalanceMap(transaction, true);
        calculateBalances();
    }

    function removeTransaction(transaction, listItem) {
        listItem.remove();
        transactions = transactions.filter(t => t !== transaction);
        updateBalanceMap(transaction, true);
        calculateBalances();
    }

    function updateBalanceMap(transaction, isRemoval = false) {
        const { amount, fromAccount, toAccount } = transaction;

        if (!balanceMap[fromAccount]) balanceMap[fromAccount] = 0;
        if (!balanceMap[toAccount]) balanceMap[toAccount] = 0;

        if (isRemoval) {
            balanceMap[fromAccount] += amount;
            balanceMap[toAccount] -= amount;
        } else {
            balanceMap[fromAccount] -= amount;
            balanceMap[toAccount] += amount;
        }
    }

    function calculateBalances() {
        // Clear the balance list before updating
        balanceList.innerHTML = '';

        const debtMap = {};

        // Initialize debtMap with zeros
        categories.forEach(category => {
            debtMap[category] = {};
            categories.forEach(otherCategory => {
                if (category !== otherCategory) {
                    debtMap[category][otherCategory] = 0;
                }
            });
        });

        // Populate debtMap based on transactions
        transactions.forEach(transaction => {
            const { amount, fromAccount, toAccount } = transaction;
            if (fromAccount !== toAccount) {
                debtMap[fromAccount][toAccount] += amount;
                debtMap[toAccount][fromAccount] -= amount;
            }
        });

        // Generate and display debts
        Object.entries(debtMap).forEach(([payer, debts]) => {
            Object.entries(debts).forEach(([payee, amount]) => {
                if (amount > 0) {
                    const li = document.createElement('li');
                    li.textContent = `${payee} deve ${amount.toFixed(2).replace('.', ',')} CHF a ${payer}`;
                    balanceList.appendChild(li);
                }
            });
        });
    }
});

